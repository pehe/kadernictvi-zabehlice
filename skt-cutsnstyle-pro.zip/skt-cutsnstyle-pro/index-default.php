<style>body, .price-table{font-family:'Arimo', sans-serif;}body, .contact-form-section .address,  .accordion-box .acc-content{color:#78797c;}body{font-size:13px}.header .header-inner .logo img {
    height: 55px;
}.header .header-inner .logo h1, .header .header-inner .logo a {font-family:Roboto;color:#f00a77;font-size:36px}.header span.tagline{color:#f00a77;}.header .header-inner .nav, .header .header-inner .nav ul li:hover > ul{background-color:#ffffff;}.header .header-inner .nav ul li, .header .header-inner .nav ul li ul li{border-color:#e7e6e6;}.header .header-inner .nav ul{font-family:'Roboto', sans-serif;font-size:14px}.header .header-inner .nav ul li a, .header .header-inner .nav ul li.current_page_item ul li a{color:#1a191e;}.header .header-inner .nav ul li a:hover, .header .header-inner .nav ul li.current_page_item a, .header .header-inner .nav ul li.current_page_item ul li a:hover, .header .header-inner .nav ul li.current-menu-ancestor a.parent{ color:#f00a77;}.time-table{background-color:rgba(0,0,0,0.6);}.time-table h2, .timingbox{border-color:#434548; }.time-table, .time-table h2{color:#ffffff;}h2.section_title{font-size:38px}.time-table, h2.section_title, .three_column, .three_column h2, .teammember-list h4, .teammember-padding, .member-desination, .date-news, .date-news span.newsdate, .client-say, h1.entry-title, h1.page-title{border-color: #f1177e}.wrap_one h1, .news h3{border-color: #eceaeb}.wrap_one h1{color:#343434; font-size:64px; }h2.section_title{font-family:'Roboto', sans-serif;color:#343434}a, .header .header-inner .header_info span.phone-no a, .tabs-wrapper ul.tabs li a, .slide_toggle a{color:#f00a77;}a:hover, .header .header-inner .header_info span.phone-no a:hover, .tabs-wrapper ul.tabs li a:hover, .slide_toggle a:hover{color:#e7e6e6;}.cols-3 h5{color:#ffffff; font-size:26px; }.cols-3{color:#8e8d8d;}.copyright-txt{color:#ffffff}.design-by{color:#ffffff}.header{background-color:#000000;}.social-icons a{background-color:#d4d3d3; color:#ffffff; border-radius:50%;}.social-icons a:hover{background-color:#f1177e; color:#ffffff; }.header .header-inner .header_info .apointment a, .button, #commentform input#submit, input.search-submit, .post-password-form input[type=submit], p.read-more a, .accordion-box h2:before, .pagination ul li span, .pagination ul li a{background-color:#f00a77; color:#ffffff; }.header .header-inner .header_info .apointment a:hover, .button:hover, #commentform input#submit:hover, input.search-submit:hover, .post-password-form input[type=submit]:hover, p.read-more a:hover, .pagination ul li .current, .pagination ul li a:hover{background-color:#343434; color:#ffffff;}.searchbox-icon, .searchbox-submit {background-color:#f1177e; }.photobooth .filter-gallery ul li.current a{border-color:#f1177e; }.wrap_one .fa{color:#f1177e; }.wrap_one h2 {color:#000000; }h3.widget-title{background-color:#f1177e; color:#ffffff;}#footer-wrapper{background-color:#121212; }.widget-column-2, ul.recent-post li, ul.recent-post li img{border-color:#3b3b3b;}.cols-3 ul li a, .phone-no span, .phone-no a:hover{color:#f00a77; }.cols-3 ul li a:hover, .phone-no a{color:#8e8d8d; }.copyright-wrapper{background-color:#000000;}.photobooth .gallery ul li:hover{ background:#f1177e;}.nivo-controlNav a{background-color:#ffffff}.nivo-controlNav a.active{background-color:#f00a77}.nivo-controlNav a{border-color:#ffffff}#sidebar ul li a{color:#78797c; border-bottom:1px dashed #d0cfcf}#sidebar ul li a:hover{color:#f1177e; }.slide_info h2{ color:#ffffff; font-size:40px;}.slide_info h2{font-family:'Roboto', sans-serif;}.slide_info p{font-family:'Roboto', sans-serif;}.slide_info p{ color:#ffffff; font-size:14px;}.copyright-wrapper a{ color: #f00a77; }.copyright-wrapper a:hover{ color: #ffffff; }.teammember-list h4, .member-desination, .teammember-list p{ color:#212121; }.three_column p, .teammember-list p{font-size:16px}.three_column p, .teammember-list h4, .member-desination, .teammember-list p{font-family:'Roboto', sans-serif;}.team-thumb-icons, .news-box .news-thumb, .news-box:hover .date-news{background-color:#f1177e;}.member-social-icon a{background:#ffffff;}.member-social-icon a{color:#222222; }.teammember-content{background-color:#f7f6f6;}.member-social-icon a:hover{ color:#f04696; }iframe{ border:1px solid #e5e5e4; }aside.widget{ background-color:#f9f9f9; }.view-all-btn a{ border:1px solid #454545; border-left:5px solid #454545; }.view-all-btn a:hover{ border-color:#f1177e; }.toggle a{ background-color:#f00a77; }.say_thumb{ background-color:#ffffff; }#testimonials ul li .tm_description{background-color: #f8f8f8; }ol.nav-numbers li a{background-color: #464d51; border:2px solid #464d51; }ol.nav-numbers li.active a{background-color: #ffffff; border:2px solid #464d51; }@media screen and (max-width: 1169px){.header .header-inner .nav{background-color: #ffffff;}}h1{font-family:Roboto;}h1{font-size:32px;}section h2 span{color:1;}h1{color:#343434;}h2{font-family:Roboto;}h2{font-size:26px;}h2{color:#343434;}h3{font-family:Roboto;}h3{font-size:18px;}h3{color:#343434;}h4{font-family:Roboto;}h4{font-size:22px;}h4{color:#343434;}h5{font-family:Roboto;}h5{font-size:20px;}h5{color:#343434;}h6{font-family:Roboto;}h6{font-size:16px;}h6{color:#343434;}</style>
</head>

<body class="home blog">
<div class="header">

<div class="header-inner">
    <div class="logo">
        <a href="<?php echo home_url(); ?>">
                           <img src="<?php echo get_template_directory_uri(); ?>/images/logo.png" / >
                    </a>
    </div><!-- logo -->  
                 
 <div class="header_info">
                   <div class="apointment"><a href="#">Book an Appointment</a></div>	
            <div class="phoneemailfix">
            <span class="phone-no"><i class="fa fa-phone"></i><a href="tel:(012) 345 6789"> (012) 345 6789</a></span>
            <span class="email-id"><i class="fa fa-envelope-o"></i><a href="mailto:hello@example.com"> hello@example.com</a></span>
            </div>
            <div class="clear"></div>
     </div><!--header_info-->
 <div class="clear"></div>
                                
                <div class="toggle">
                <a class="toggleMenu" href="#">Menu</a>
                </div><!-- toggle -->
                <div class="nav">                   
                	<ul>
                    	<li class="current_page_item"><a href="<?php echo home_url(); ?>">Home</a></li>
						<?php $howmany = 5;
                            $pages = wp_list_pages("echo=0&title_li=");
                            $pages_arr = explode("\n", $pages);
                            for($i=0;$i<$howmany;$i++){
                                echo $pages_arr[$i];
                            }
                        ?>
                    </ul>    
                </div><!-- nav --><div class="clear"></div>
</div><!-- header-inner -->
</div><!-- header -->


    <div class="slider-main">
        <div id="slider" class="nivoSlider">
                <img src="<?php echo get_template_directory_uri(); ?>/images/slides/slider1.jpg" alt="" title="#slidecaption1"/>               
 		</div> 
        <div id="slidecaption1" class="nivo-html-caption">
            <div class="slide_info">
                <a href=""><h2>Create Your <strong>Hair Style</strong> With Us</h2></a>						
            </div>
        </div>                         
                    
        <div class="clear"></div>        
		<div class="time-table">
            <h2>Opening Time table</h2>
            <div class="timingbox">
				<div class="openingday"><div>Monday</div></div>
				<div class="openingtime"><div class="">8:00 - 16:00 </div></div>
				<div class="clear"></div>
				</div><div class="timingbox">
				<div class="openingday"><div>Tuesday</div></div>
				<div class="openingtime"><div class="">8:00 - 16:00 </div></div>
				<div class="clear"></div>
				</div><div class="timingbox">
				<div class="openingday"><div>Wednesday</div></div>
				<div class="openingtime"><div class="">10:00 - 14:00 </div></div>
				<div class="clear"></div>
				</div><div class="timingbox">
				<div class="openingday"><div>Thursday</div></div>
				<div class="openingtime"><div class="">10:00 - 13:00</div></div>
				<div class="clear"></div>
				</div><div class="timingbox">
				<div class="openingday"><div>Friday</div></div>
				<div class="openingtime"><div class="">10:00 - 12:00</div></div>
				<div class="clear"></div>
				</div><div class="timingbox">
				<div class="openingday"><div>Saturday</div></div>
				<div class="openingtime"><div class="">Close</div></div>
				<div class="clear"></div>
				</div><div class="timingbox">
				<div class="openingday"><div>Sunday</div></div>
				<div class="openingtime"><div class="">Close</div></div>
				<div class="clear"></div>
				</div>         </div>
                </div>
                <div class="clear"></div>                
        </div>
    </div><!-- slider -->
	  

	            <section style="background-color:#ffffff; " id="" class="">
            	<div class="container">
                    <div class="wrap_one">
                                            <h1>Welcome</h1>
<div class="welcome-text">Nunc faucibus velit ut tortor accumsan ultrices. Aliquam placerat libero vel pharetra placerat. Ut euismod elit id dui tincidunt rhont cusing. Proin pellentesque consequat finibus. Fusce pulvinar tortor sit amet ipsum lacinia, egestas mollis tortor scelerisque. Proin consequatted aliquet eleifend. Mauris laoreet ligula non metus tristique sodales. Pellentesque nec vehicula magna, sed convallis eros. Integer eget and dolor nunc. Nulla sem nibh, pellentesque ac posuere sit amet, lobortis eu nisi. Aliquam nulla ex, elementum ut porttitor vitae, tincidunt on vitae mauris.</div>
                     </div><!-- middle-align -->
                    <div class="clear"></div>
                    </div><!-- container -->
            </section><div class="clear"></div>
        
                        <section style="background-color:#fbfafa; " id="" class="">
            	<div class="container">
                    <div class="services-wrap">
                                                <h2 class="section_title">Our Services</h2>
                                        <div class="services-members"><div class="three_column"><a href="#">
		
		<div class="services-thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/thumb1.jpg" class="attachment-post-thumbnail wp-post-image" alt="Services" /></div>
		<div class="services-content">
								<h2>Hair Style</h2>
								<p>Nunc faucibus velit ut tortor accumsan ultrices. Aliquam&#8230;</p>

								</div>
								
								</a></div><div class="three_column"><a href="#">
		
		<div class="services-thumb"><img width="340" height="279" src="<?php echo get_template_directory_uri(); ?>/images/thumb2.jpg" class="attachment-post-thumbnail wp-post-image" alt="services-2" /></div>
		<div class="services-content">
								<h2>Make Up</h2>
								<p>Nunc faucibus velit ut tortor accumsan ultrices. Aliquam&#8230;</p>

								</div>
								
								</a></div><div class="three_column servicesnomargn"><a href="#">
		
		<div class="services-thumb"><img width="340" height="279" src="<?php echo get_template_directory_uri(); ?>/images/thumb3.jpg" class="attachment-post-thumbnail wp-post-image" alt="Nails" /></div>
		<div class="services-content">
								<h2>Nails</h2>
								<p>Nunc faucibus velit ut tortor accumsan ultrices. Aliquam&#8230;</p>

								</div>
								
								</a></div><div class="clear"></div><div class="clear"></div></div>
                     </div><!-- middle-align -->
                    <div class="clear"></div>
                    </div><!-- container -->
            </section><div class="clear"></div>
        
                        <section style="background-color:#ffffff; " id="" class="">
            	<div class="container">
                    <div class="team-wrap">
                                                <h2 class="section_title">Our Team</h2>
                                        <div class="section-teammember"><div class="teammember-list"><h4>Aliquam Felis</h4><div class="teammember-padding"><div class="team-thumb-icons">
			
			<a href="#" title="Aliquam Felis">
			<img width="340" height="279" src="<?php echo get_template_directory_uri(); ?>/images/img_404.png" class="attachment-post-thumbnail wp-post-image" alt="team-2" /></a>
				<div class="member-social-icon"><a href="#" title="facebook" target="_blank"><i class="fa fa-facebook fa-lg"></i></a><a href="#" title="twitter" target="_blank"><i class="fa fa-twitter fa-lg"></i></a><a href="#" title="youtube" target="_blank"><i class="fa fa-youtube fa-lg"></i></a><a href="#" title="linkedin" target="_blank"><i class="fa fa-linkedin fa-lg"></i></a></div></div><div class="teammember-content">
							<span class="member-desination">Designation</span>
				 			<p><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec&#8230;</p>
</p></div></div></div><div class="teammember-list"><h4>Imperdiet nulla</h4><div class="teammember-padding"><div class="team-thumb-icons">
			
			<a href="#" title="Imperdiet nulla">
			<img src="<?php echo get_template_directory_uri(); ?>/images/img_404.png" /></a>
				<div class="member-social-icon"></div></div><div class="teammember-content">
							<span class="member-desination"></span>
				 			<p><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec&#8230;</p>
</p></div></div></div><div class="teammember-list last"><h4>Etiam Luctus</h4><div class="teammember-padding"><div class="team-thumb-icons">
			
			<a href="#" title="Etiam Luctus">
			<img width="340" height="279" src="<?php echo get_template_directory_uri(); ?>/images/img_404.png" class="attachment-post-thumbnail wp-post-image" alt="team-3" /></a>
				<div class="member-social-icon"><a href="#" title="facebook" target="_blank"><i class="fa fa-facebook fa-lg"></i></a><a href="#" title="youtube" target="_blank"><i class="fa fa-youtube fa-lg"></i></a><a href="#" title="linkedin" target="_blank"><i class="fa fa-linkedin fa-lg"></i></a><a href="#" title="rss" target="_blank"><i class="fa fa-rss fa-lg"></i></a></div></div><div class="teammember-content">
							<span class="member-desination">Designation</span>
				 			<p><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec&#8230;</p>
</p></div></div></div><div class="clear"></div></div>
                     </div><!-- middle-align -->
                    <div class="clear"></div>
                    </div><!-- container -->
            </section><div class="clear"></div>
        
                        <section style="background-color:#ffffff; background-image:url(<?php echo get_template_directory_uri(); ?>/images/pricing-table.jpg); background-repeat:no-repeat; background-position: center center; background-size: cover; " id="" class="">
            	<div class="container">
                    <div class="our-pricing-table">
                                                <h2 class="section_title">Check Our Pricing Table</h2>
                                        <div class="pricing-table-content"  style="background-color:#ffffff; color:;" ><div class="pricing-table" style="border-bottom:dashed 1px #c9c9c9 !important;">
					<span class="hairservice">Trim your Beard</span>
					<span class="hairprice">$ 15.99</span>
					<div class="clear"></div>
				</div><div class="pricing-table" style="border-bottom:dashed 1px #c9c9c9 !important;">
					<span class="hairservice">Trim your Hair</span>
					<span class="hairprice">$ 15.99</span>
					<div class="clear"></div>
				</div><div class="pricing-table" style="border-bottom:dashed 1px #c9c9c9 !important;">
					<span class="hairservice">Special Beard Treatment</span>
					<span class="hairprice">$ 15.99</span>
					<div class="clear"></div>
				</div><div class="pricing-table" style="border-bottom:dashed 1px #c9c9c9 !important;">
					<span class="hairservice">Color your Beard</span>
					<span class="hairprice">$ 15.99</span>
					<div class="clear"></div>
				</div><div class="pricing-table" style="border-bottom:dashed 1px #c9c9c9 !important;">
					<span class="hairservice">Wax your Beard</span>
					<span class="hairprice">$ 15.99</span>
					<div class="clear"></div>
				</div><div class="pricing-table" >
					<span class="hairservice">Complete Treatment</span>
					<span class="hairprice">$ 15.99</span>
					<div class="clear"></div>
				</div></div>
                     </div><!-- middle-align -->
                    <div class="clear"></div>
                    </div><!-- container -->
            </section><div class="clear"></div>
        
                        <section style="background-color:#fbfafa; " id="" class="">
            	<div class="container">
                    <div class="latestposts">
                                                <h2 class="section_title">Latest Posts</h2>
                                        <div class="news-box  ">
								<div class="news-thumb">
									<a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/img_404.png" alt=" " /></a> 
								</div>
								<div class="news">
									<div class="date-news">
										<span class="newsdate">03</span>
										<span>Aug</span>
									</div>
									<a href="#"><h3>Praesent aliquamar cut sapien.</h3></a>
									 <p>Aliquam et varius orci, ut ornare justo. Lorem ipsum dolor sit amet.</p>
 
								</div>
                        </div><div class="news-box last">
								<div class="news-thumb">
									<a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/img_404.png" alt=" " /></a>
								</div>
								<div class="news">
									<div class="date-news">
										<span class="newsdate">03</span>
										<span>Aug</span>
									</div>
									<a href="#"><h3>Praesent aliquamar cut sapien.</h3></a>
									 <p>Aliquam et varius orci, ut ornare justo. Lorem ipsum dolor sit amet.</p>
 
								</div>
                        </div><div class="clear"></div><div class="news-box  ">
								<div class="news-thumb">
									<a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/img_404.png" alt=" " /></a>
								</div>
								<div class="news">
									<div class="date-news">
										<span class="newsdate">03</span>
										<span>Aug</span>
									</div>
									<a href="#"><h3>Praesent aliquamar cut sapien.</h3></a>
									 <p>Aliquam et varius orci, ut ornare justo. Lorem ipsum dolor sit amet.</p>
 
								</div>
                        </div><div class="news-box last">
								<div class="news-thumb">
									<a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/img_404.png" alt=" " /></a>
								</div>
								<div class="news">
									<div class="date-news">
										<span class="newsdate">03</span>
										<span>Aug</span>
									</div>
									<a href="#"><h3>Praesent aliquamar cut sapien.</h3></a>
									<p>Aliquam et varius orci, ut ornare justo. Lorem ipsum dolor sit amet.</p>
 
								</div>
                        </div><div class="clear"></div>
                     </div><!-- middle-align -->
                    <div class="clear"></div>
                    </div><!-- container -->
            </section><div class="clear"></div>
        
                        <section style="background-color:#ffffff; " id="" class="">
            	<div class="container">
                    <div class="testimonials-wrap">
                                                <h2 class="section_title">Testimonials</h2>
                                        <div id="testimonials">
			     <div class="client-say  ">
				  <div class="say_thumb"> <img width="105" height="105" src="<?php echo get_template_directory_uri(); ?>/images/testimonial.png" class="attachment-105x105 wp-post-image" alt="team-3" /> </div> 	                  
				  <div class="tm_description">
				   <p><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#8217;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make&#8230;</p>
</p>          
					<h5><span></span> Suscipit libero</h5>  
				  </div> 
				  <div class="clear"></div>				  			              
			  	</div>
				 
			     <div class="client-say client-say-last">
				  <div class="say_thumb"> <img width="105" height="105" src="<?php echo get_template_directory_uri(); ?>/images/testimonial.png" class="attachment-105x105 wp-post-image" alt="latest-post3" /> </div> 	                  
				  <div class="tm_description">
				   <p><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#8217;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make&#8230;</p>
</p>          
					<h5><span></span> Suscipit libero</h5>  
				  </div> 
				  <div class="clear"></div>				  			              
			  	</div>
				 </div></div>
                     </div><!-- middle-align -->
                    <div class="clear"></div>
                    </div><!-- container -->
            </section><div class="clear"></div>
        
                        <section style="background-image:url(<?php echo get_template_directory_uri(); ?>/images/allday.jpg); background-repeat:no-repeat; background-position: center center; background-size: cover; " id="" class="">
            	<div class="container">
                    <div class="">
                                            <div id="some-facts"><div class="everydaytime">
				<div class="everydays" style="background-color:#fff; color:#5b5a5a;" >Mon</div>
				<div class="everytime">8:00 &#8211; 16:00</div>
			</div> <div class="everydaytime">
				<div class="everydays" style="background-color:#fff; color:#5b5a5a;" >Tue</div>
				<div class="everytime">8:00 &#8211; 16:00</div>
			</div><div class="everydaytime">
				<div class="everydays" style="background-color:#fff; color:#5b5a5a;" >Wed</div>
				<div class="everytime">8:00 &#8211; 16:00</div>
			</div> <div class="everydaytime">
				<div class="everydays" style="background-color:#fff; color:#5b5a5a;" >Thu</div>
				<div class="everytime">8:00 &#8211; 16:00</div>
			</div> <div class="everydaytime">
				<div class="everydays" style="background-color:#fff; color:#5b5a5a;" >Fri</div>
				<div class="everytime">8:00 &#8211; 16:00</div>
			</div> <div class="everydaytime">
				<div class="everydays" style="background-color:#000; color:#5b5a5a;" >Sat</div>
				<div class="everytime">CLOSED</div>
			</div><div class="everydaytime">
				<div class="everydays" style="background-color:#000; color:#5b5a5a;" >Sun</div>
				<div class="everytime">CLOSED</div>
			</div></div>
                     </div><!-- middle-align -->
                    <div class="clear"></div>
                    </div><!-- container -->
            </section><div class="clear"></div>
        
                        <section style="background-color:#ffffff; " id="home-gallery" class="menu_page">
            	<div class="container">
                    <div class="">
                                                <h2 class="section_title">Gallery</h2>
                                        <div class="photobooth"><div class="gallery">
                                        
                                        <ul class="clean" id="portfolio"><li class="hair-style make-up" >
                <strong>Hair Style</strong>                
 <a href="<?php echo get_template_directory_uri(); ?>/images/galleryimg1.jpg" rel="prettyPhoto[pp_gal]"><img src="<?php echo get_template_directory_uri(); ?>/images/galleryimg1.jpg"/></a>
            </li><li class="nail-style" >
                <strong>Nails</strong>                
 <a href="<?php echo get_template_directory_uri(); ?>/images/galleryimg2.jpg" rel="prettyPhoto[pp_gal]"><img src="<?php echo get_template_directory_uri(); ?>/images/galleryimg2.jpg"/></a>
            </li><li class="hair-style" >
                <strong>Make Up</strong>                
 <a href="<?php echo get_template_directory_uri(); ?>/images/galleryimg3.jpg" rel="prettyPhoto[pp_gal]"><img src="<?php echo get_template_directory_uri(); ?>/images/galleryimg3.jpg"/></a>
            </li><li class="make-up" style="margin-right:0">
                <strong>Hair Style</strong>                
 <a href="<?php echo get_template_directory_uri(); ?>/images/galleryimg4.jpg" rel="prettyPhoto[pp_gal]"><img src="<?php echo get_template_directory_uri(); ?>/images/galleryimg4.jpg"/></a>
            </li></ul></div><div class="clear"></div></div>
                     </div><!-- middle-align -->
                    <div class="clear"></div>
                    </div><!-- container -->
            </section><div class="clear"></div>
        
                        <section style="background-color:#ffffff; " id="home-social-icons" class="menu_page">
            	<div class="container">
                    <div class="">
                                                <h2 class="section_title">Get in Touch</h2>
                                        <div class="social-icons"><a href="#" target="_blank" class="fa fa-facebook fa-2x" title="facebook"></a> <a href="#" target="_blank" class="fa fa-twitter fa-2x" title="twitter"></a> <a href="#" target="_blank" class="fa fa-google fa-2x" title="google"></a> <a href="#" target="_blank" class="fa fa-pinterest fa-2x" title="pinterest"></a> <a href="#" target="_blank" class="fa fa-youtube fa-2x" title="youtube"></a> <a href="#" target="_blank" class="fa fa-linkedin-square fa-2x" title="linkedin-square"></a> <a href="#" target="_blank" class="fa fa-vimeo-square fa-2x" title="vimeo-square"></a> <a href="#" target="_blank" class="fa fa-rss fa-2x" title="rss"></a> <a href="#" target="_blank" class="fa fa-instagram fa-2x" title="instagram"></a> <a href="#" target="_blank" class="fa fa-tumblr fa-2x" title="tumblr"></a> <a href="#" target="_blank" class="fa fa-flickr fa-2x" title="flickr"></a> <a href="#" target="_blank" class="fa fa-yahoo fa-2x" title="yahoo"></a> <a href="#" target="_blank" class="fa fa-dribbble fa-2x" title="dribbble"></a> <a href="#" target="_blank" class="fa fa-stumbleupon fa-2x" title="stumbleupon"></a> <a href="#" target="_blank" class="fa fa-meanpath fa-2x" title="meanpath"></a> <a href="#" target="_blank" class="fa fa-behance fa-2x" title="behance"></a> <a href="#" target="_blank" class="fa fa-codepen fa-2x" title="codepen"></a> <a href="#" target="_blank" class="fa fa-git fa-2x" title="git"></a> <a href="#" target="_blank" class="fa fa-foursquare fa-2x" title="foursquare"></a> <a href="#" target="_blank" class="fa fa-wordpress fa-2x" title="wordpress"></a> <a href="#" target="_blank" class="fa fa-yelp fa-2x" title="yelp"></a> <a href="#" target="_blank" class="fa fa-mail-forward fa-2x" title="mail-forward"></a> <a href="#" target="_blank" class="fa fa-vk fa-2x" title="vk"></a> <a href="#" target="_blank" class="fa fa-rocket fa-2x" title="rocket"></a> <a href="#" target="_blank" class="fa fa-whatsapp fa-2x" title="whatsapp"></a> <a href="#" target="_blank" class="fa fa-medium fa-2x" title="medium"></a> <a href="#" target="_blank" class="fa fa-linkedin fa-2x" title="linkedin"></a> <a href="#" target="_blank" class="fa fa-globe fa-2x" title="globe"></a> <a href="#" target="_blank" class="fa fa-magnet fa-2x" title="magnet"></a> <a href="#" target="_blank" class="fa fa-google-plus-square fa-2x" title="google-plus-square"></a> <a href="#" target="_blank" class="fa fa-link fa-2x" title="link"></a> <a href="#" target="_blank" class="fa fa-vine fa-2x" title="vine"></a> <a href="#" target="_blank" class="fa fa-yelp fa-2x" title="yelp"></a> <a href="#" target="_blank" class="fa fa-envelope-o fa-2x" title="envelope-o"></a></div>
                     </div><!-- middle-align -->
                    <div class="clear"></div>
                    </div><!-- container -->
            </section><div class="clear"></div>
        
            <div id="footer-wrapper">
    	<div class="container">
        	
        	  
             <div class="cols-3 widget-column-1">            	
               <h5>About Cuts n Style</h5>
               <p>Donec ut ex ac nulla pellentesque mollis in a enim. Praesent placerat sapien mauris, vitae sodales tellus venenatis ac. Suspendisse suscipit velit id ultricies auctor. Duis turpis arcu, aliquet sed sollicitudin sed, porta quis urna. Quisque velit nibh, egestas et erat a, vehicula interdum augue. Morbi ut elementum justo. Sed eu nibh orci. Vivamus elementum erat orci. Curabitur consequat convallis dapibus.</p>                 <div class="clear"></div>    
              </div>                  
			           
             <div class="cols-3 widget-column-2">          
            	<h5>Recent Posts</h5>
                 <ul class="recent-post">
                	                                      	<li>
                    
<a href="#">
	<img src="<?php echo get_template_directory_uri(); ?>/images/postthum1.jpg" alt="" width="60" height="auto" ></a>
					<p>Aliquam et varius orci, ut ornare justo. Lorem ipsum&#8230;</p>
                    <a href="#"><span> Read more...</span></a>
                    </li>
                                      	<li>
                    
<a href="#">
	<img src="<?php echo get_template_directory_uri(); ?>/images/postthum2.jpg" alt="" width="60" height="auto" ></a>
					<p>Aliquam et varius orci, ut ornare justo. Lorem ipsum&#8230;</p>
                    <a href="#"><span> Read more...</span></a>
                    
                    </li>
                                                        </ul>
              </div>             
                      
                          <div class="cols-3 widget-column-3">                
            	<h5>Cuts n Style</h5>
               	
                <p>Street 238,52 tempor</p>
                <p>Donec ultricies mattis nulla, suscipit risus iru iru tritique ut.</p>
                <div class="phone-no">
                	                		<p><span>Phone:</span>(012) 345 6789</p>
                                                            <p><span>E-mail:</span><a href="mailto:hello@example.com">hello@example.com</a></p>
                                                            	<p><span>Website:</span><a href="http://demo.com" target="_blank">http://demo.com</a></p>
                                    </div>
               </div>
                        
            <div class="clear"></div>
        </div><!--end .container-->
        
        <div class="copyright-wrapper">
        	<div class="container">
            	<div class="copyright-txt">&copy; 2015 <a href="#">SKT Cutsnstyle. </a> All Rights Reserved</div>
                <div class="design-by">Design by <a href="http://www.sktthemes.net/" target="_blank">SKT Themes</a></div>
            </div>
            <div class="clear"></div>
        </div>
    </div>
</body>
</html>