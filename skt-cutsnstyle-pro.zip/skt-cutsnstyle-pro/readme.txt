/*-----------------------------------------------------------------------------------*/
/* SKT Cutsnstyle PRO Responsive WordPress Theme */
/*-----------------------------------------------------------------------------------*/

Theme Name      :   SKT Cutsnstyle PRO
Theme URI       :   http://www.sktthemes.net/shop/cutnstyle/
Version         :   pro1.2
Tested up to    :   WP 4.6.1
Author          :   SKT Themes
Author URI      :   http://www.sktthemes.net/

license         :   GNU General Public License v3.0
License URI     :   http://www.gnu.org/licenses/gpl.html

/*-----------------------------------------------------------------------------------*/
/* About Author - Contact Details */
/*-----------------------------------------------------------------------------------*/

email       :   support@sktthemes.com

/*-----------------------------------------------------------------------------------*/
/* Theme Resources */
/*-----------------------------------------------------------------------------------*/

Theme is Built using the following resource bundles.




1 - All js that have been used are within folder /js of theme.
- jquery.easing.min.js is licensed under BSD.
- jquery.prettyPhoto.js is licensed under GPLv2.
- html5.js is dual licensed under MIT and GPL2.
- jquery.nivo.slider.js is licensed under MIT.


2 - Roboto- https://www.google.com/fonts/specimen/Roboto
	License: Distributed under the terms of the Apache License, version 2.0 		http://www.apache.org/licenses/

3 - Images used from Pixabay.
	License: Distributed under the terms of the GPLv2
	Image urls : used within the themes

	Slides:

	https://pixabay.com/en/model-fashion-glamour-girl-female-600238/
	https://pixabay.com/en/woman-portrait-face-model-canon-659352/
	https://pixabay.com/en/beauty-portrait-pose-posing-girl-666605/

	Other Images

	https://pixabay.com/en/girl-view-woman-dress-hands-567774/
	https://pixabay.com/en/girl-people-landscape-sun-657753/
	https://pixabay.com/en/girls-hair-care-two-daughter-487097/
	https://pixabay.com/en/glazes-beauty-sets-colors-red-388384/
	https://pixabay.com/en/makeup-face-eyes-blonde-girls-487063/
	https://pixabay.com/en/man-person-fashion-male-handsome-601539/
	https://pixabay.com/en/model-female-girl-beautiful-woman-429733/
	https://pixabay.com/en/studio-portrait-model-woman-face-660804/


For any help you can mail us at support[at]sktthemes.com